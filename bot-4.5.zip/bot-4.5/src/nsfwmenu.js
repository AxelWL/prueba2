const nsfwmenu = (prefix, pushname) => {
    return `*Comandos para ver pornito 🔞*
*NSFW ✅*

- ${prefix}nsfwbobs
- ${prefix}nsfwsidebobs
- ${prefix}nsfwahegao
- ${prefix}nsfwfeets

_El bot nesecita admin y tener activado los NSFW_\n _Digita_\n ${prefix}*nsfw 1*

Algunas funciones fueron eliminas por errores en el servidor de la India

ву ѕнαη∂υу`

}

exports.nsfwmenu = nsfwmenu

const version = (prefix, pushname) => {
    return `
*AxelBot by Axel*

*Actualizado:* 03 de Diciembre del 2021
*Versión actual:* 4.4
*Ofrecida por:* Axel™


*INFORME*

Si no funciona el comando *play o *play2 checa el blog del bot y mira la version que poses 
Ya que ire cambiando mi apikey de mi bot para que siga en funcionamiento
Cambiare la apikey pasando un mes o si veo muchos atercados o robos
Si vez a alguien que robo mi bot comunicate conmigo con el comando *creador















_*by AXEL*_
`

}

exports.version = version

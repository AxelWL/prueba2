const juegos = (prefix, pushname) => {
    return `
*Comandos De Juegos 👾*
 
${prefix}rankgay
Conoce a el top de los mas gays del grupo

${prefix}gay
Conoce que tan gay eres 😎

${prefix}cuties
Prueba tu suerte en el medidor de fan de cuties 😱

_*En futuras versiones colocare mas juegos :)*_
     
_*by axel*_
`

}

exports.juegos = juegos

const config = {
        botName: 'AxelBot',
        ownerName: 'Axel',
       
}